# 📅 Team Scheduler

Intelligente Terminplanung mit Routenoptimierung für Teams.

---

## 🚀 Deployment auf Vercel (KOSTENLOS)

### Voraussetzungen
- Ein GitHub-Konto (kostenlos: github.com)
- Ein Vercel-Konto (kostenlos: vercel.com)

---

## Schritt-für-Schritt Anleitung

### 1️⃣ GitHub Repository erstellen

1. Gehe zu **github.com** und logge dich ein (oder erstelle ein Konto)
2. Klicke oben rechts auf **"+"** → **"New repository"**
3. Name: `team-scheduler`
4. Klicke auf **"Create repository"**

### 2️⃣ Dateien hochladen

**Option A: Über die GitHub-Webseite (einfach)**

1. In deinem neuen Repository, klicke auf **"uploading an existing file"**
2. Ziehe ALLE Dateien aus diesem Ordner per Drag & Drop hinein:
   - `package.json`
   - `vite.config.js`
   - `index.html`
   - `src/` Ordner (mit allen Dateien)
   - `public/` Ordner (mit favicon.svg)
3. Klicke auf **"Commit changes"**

**Option B: Mit Git (für Fortgeschrittene)**

```bash
cd team-scheduler-app
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/DEIN-USERNAME/team-scheduler.git
git push -u origin main
```

### 3️⃣ Mit Vercel verbinden

1. Gehe zu **vercel.com** und klicke auf **"Sign Up"**
2. Wähle **"Continue with GitHub"**
3. Erlaube Vercel Zugriff auf dein GitHub-Konto
4. Klicke auf **"Add New..."** → **"Project"**
5. Wähle dein Repository **"team-scheduler"** aus
6. Klicke auf **"Deploy"**

### 4️⃣ Fertig! 🎉

Nach ca. 1-2 Minuten ist deine App live unter:
```
https://team-scheduler-XXXXX.vercel.app
```

Du bekommst die URL direkt auf der Vercel-Seite angezeigt.

---

## 📁 Projektstruktur

```
team-scheduler-app/
├── package.json          # Projektinfo & Dependencies
├── vite.config.js        # Build-Konfiguration
├── index.html            # Haupt-HTML
├── public/
│   └── favicon.svg       # Browser-Icon
└── src/
    ├── main.jsx          # React-Einstiegspunkt
    ├── App.jsx           # Hauptkomponente
    └── index.css         # Globale Styles
```

---

## ✨ Features

- 📅 **Kalender-Ansicht** für mehrere Mitarbeiter
- 🎯 **Intelligente Terminvorschläge** basierend auf Verfügbarkeit
- 🚗 **Fahrzeit-Berechnung** (simuliert im Demo-Modus)
- 📍 **Adress-basierte Planung** für Außentermine
- 👥 **Multi-Teilnehmer-Termine**

---

## 🔧 Lokale Entwicklung (optional)

Falls du die App lokal testen möchtest:

```bash
# Node.js installieren von nodejs.org (falls nicht vorhanden)

# Im Projektordner:
npm install
npm run dev

# Öffne http://localhost:5173
```

---

## 🔑 API-Integration (Zukunft)

Für echte Kalender-Integration werden benötigt:

| API | Kosten | Wofür |
|-----|--------|-------|
| Google Calendar API | Kostenlos | Kalender lesen/schreiben |
| Google Maps Distance Matrix | ~€5/1000 Anfragen | Echte Fahrzeiten |

**Hinweis:** Die aktuelle Version läuft im Demo-Modus ohne echte APIs.

---

## ❓ Hilfe

Bei Problemen:
1. Prüfe, ob alle Dateien korrekt hochgeladen wurden
2. Prüfe die Vercel-Konsole auf Fehlermeldungen
3. Stelle sicher, dass `package.json` im Root-Verzeichnis liegt

---

Erstellt mit ❤️ und Claude
