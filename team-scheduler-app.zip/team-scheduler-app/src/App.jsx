import React, { useState, useEffect } from 'react';

// Demo data - in production this would come from Google Calendar API
const DEMO_EMPLOYEES = [
  { 
    id: 1, 
    name: 'Anna Müller', 
    color: '#3B82F6',
    baseLocation: { lat: 53.0793, lng: 8.8017, address: 'Oldenburg, Hauptbahnhof' },
    avatar: 'AM'
  },
  { 
    id: 2, 
    name: 'Thomas Schmidt', 
    color: '#10B981',
    baseLocation: { lat: 53.0793, lng: 8.8017, address: 'Oldenburg, Hauptbahnhof' },
    avatar: 'TS'
  },
  { 
    id: 3, 
    name: 'Lisa Weber', 
    color: '#F59E0B',
    baseLocation: { lat: 53.0793, lng: 8.8017, address: 'Oldenburg, Hauptbahnhof' },
    avatar: 'LW'
  },
  { 
    id: 4, 
    name: 'Max Bauer', 
    color: '#EF4444',
    baseLocation: { lat: 53.0793, lng: 8.8017, address: 'Oldenburg, Hauptbahnhof' },
    avatar: 'MB'
  }
];

// Demo appointments
const generateDemoAppointments = () => {
  const today = new Date();
  const appointments = [];
  
  // Anna's appointments
  appointments.push(
    { id: 1, employeeId: 1, title: 'Kundentermin Meier GmbH', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 9, 0), duration: 90, address: 'Bremen, Domshof 12', type: 'external' },
    { id: 2, employeeId: 1, title: 'Team Meeting', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 14, 0), duration: 60, address: '', type: 'internal' },
    { id: 3, employeeId: 1, title: 'Projektbesprechung', date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 10, 0), duration: 120, address: '', type: 'internal' }
  );
  
  // Thomas's appointments
  appointments.push(
    { id: 4, employeeId: 2, title: 'Vor-Ort-Termin Firma Hansen', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 8, 30), duration: 120, address: 'Wilhelmshaven, Marktstr. 5', type: 'external' },
    { id: 5, employeeId: 2, title: 'Rückfahrt + Mittagspause', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12, 0), duration: 60, address: '', type: 'travel' },
    { id: 6, employeeId: 2, title: 'Telefonkonferenz', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 15, 30), duration: 45, address: '', type: 'internal' }
  );
  
  // Lisa's appointments
  appointments.push(
    { id: 7, employeeId: 3, title: 'Schulung extern', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 9, 0), duration: 240, address: 'Hannover, Messegelände', type: 'external' },
    { id: 8, employeeId: 3, title: 'Nachbereitung', date: new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, 9, 0), duration: 60, address: '', type: 'internal' }
  );
  
  // Max's appointments
  appointments.push(
    { id: 9, employeeId: 4, title: 'Vertriebsmeeting', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 11, 0), duration: 60, address: '', type: 'internal' },
    { id: 10, employeeId: 4, title: 'Kundenbesuch Norddeich', date: new Date(today.getFullYear(), today.getMonth(), today.getDate(), 14, 0), duration: 90, address: 'Norddeich, Hafenstr. 23', type: 'external' }
  );
  
  return appointments;
};

// Simulated distance/time calculation (in production: Google Maps Distance Matrix API)
const calculateTravelTime = (fromAddress, toAddress) => {
  const distances = {
    'oldenburg': { 'bremen': 45, 'wilhelmshaven': 55, 'hannover': 95, 'norddeich': 70, 'emden': 60 },
    'bremen': { 'oldenburg': 45, 'wilhelmshaven': 80, 'hannover': 75, 'norddeich': 95 },
    'wilhelmshaven': { 'oldenburg': 55, 'bremen': 80, 'norddeich': 40 },
    'hannover': { 'oldenburg': 95, 'bremen': 75 },
    'norddeich': { 'oldenburg': 70, 'wilhelmshaven': 40, 'bremen': 95 },
    'emden': { 'oldenburg': 60 }
  };
  
  const from = fromAddress.toLowerCase();
  const to = toAddress.toLowerCase();
  
  for (const [city1, routes] of Object.entries(distances)) {
    if (from.includes(city1)) {
      for (const [city2, time] of Object.entries(routes)) {
        if (to.includes(city2)) {
          return time;
        }
      }
    }
  }
  
  return Math.floor(Math.random() * 45) + 20;
};

// Main App Component
export default function App() {
  const [employees] = useState(DEMO_EMPLOYEES);
  const [appointments, setAppointments] = useState(generateDemoAppointments());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showNewAppointment, setShowNewAppointment] = useState(false);
  const [newAppointment, setNewAppointment] = useState({
    title: '',
    address: '',
    duration: 60,
    selectedEmployees: [],
    preferredDate: new Date()
  });
  const [suggestions, setSuggestions] = useState([]);
  const [showSettings, setShowSettings] = useState(false);
  const [apiKeys, setApiKeys] = useState({
    googleCalendar: '',
    googleMaps: ''
  });

  useEffect(() => {
    if (newAppointment.address && newAppointment.selectedEmployees.length > 0) {
      generateSuggestions();
    }
  }, [newAppointment.address, newAppointment.selectedEmployees, newAppointment.preferredDate]);

  const generateSuggestions = () => {
    const suggestionsArray = [];
    const baseDate = newAppointment.preferredDate;
    
    for (let dayOffset = 0; dayOffset < 5; dayOffset++) {
      const checkDate = new Date(baseDate);
      checkDate.setDate(checkDate.getDate() + dayOffset);
      
      if (checkDate.getDay() === 0 || checkDate.getDay() === 6) continue;
      
      for (let hour = 8; hour <= 16; hour++) {
        for (let minute of [0, 30]) {
          const slotStart = new Date(checkDate);
          slotStart.setHours(hour, minute, 0, 0);
          
          const slotEnd = new Date(slotStart);
          slotEnd.setMinutes(slotEnd.getMinutes() + newAppointment.duration);
          
          let allAvailable = true;
          let totalTravelTime = 0;
          
          for (const empId of newAppointment.selectedEmployees) {
            const employee = employees.find(e => e.id === empId);
            const empAppointments = appointments.filter(a => 
              a.employeeId === empId &&
              a.date.toDateString() === slotStart.toDateString()
            );
            
            for (const apt of empAppointments) {
              const aptEnd = new Date(apt.date);
              aptEnd.setMinutes(aptEnd.getMinutes() + apt.duration);
              
              let bufferBefore = 0;
              let bufferAfter = 0;
              
              if (apt.type === 'external' && apt.address) {
                bufferBefore = calculateTravelTime(employee.baseLocation.address, apt.address);
                bufferAfter = calculateTravelTime(apt.address, newAppointment.address || employee.baseLocation.address);
              }
              
              const aptStartWithBuffer = new Date(apt.date);
              aptStartWithBuffer.setMinutes(aptStartWithBuffer.getMinutes() - bufferBefore);
              
              const aptEndWithBuffer = new Date(aptEnd);
              aptEndWithBuffer.setMinutes(aptEndWithBuffer.getMinutes() + bufferAfter);
              
              if (slotStart < aptEndWithBuffer && slotEnd > aptStartWithBuffer) {
                allAvailable = false;
              }
            }
            
            if (newAppointment.address) {
              const previousApt = empAppointments
                .filter(a => a.date < slotStart)
                .sort((a, b) => b.date - a.date)[0];
              
              const fromAddress = previousApt?.address || employee.baseLocation.address;
              const travelTime = calculateTravelTime(fromAddress, newAppointment.address);
              totalTravelTime = Math.max(totalTravelTime, travelTime);
            }
          }
          
          if (allAvailable && suggestionsArray.length < 6) {
            suggestionsArray.push({
              date: new Date(slotStart),
              travelTime: totalTravelTime,
              score: calculateScore(slotStart, totalTravelTime, dayOffset),
              employees: newAppointment.selectedEmployees.map(id => 
                employees.find(e => e.id === id)
              )
            });
          }
        }
      }
    }
    
    suggestionsArray.sort((a, b) => b.score - a.score);
    setSuggestions(suggestionsArray.slice(0, 5));
  };

  const calculateScore = (date, travelTime, dayOffset) => {
    let score = 100;
    score -= travelTime * 0.5;
    score -= dayOffset * 10;
    const hour = date.getHours();
    if (hour >= 9 && hour <= 11) score += 15;
    if (hour >= 14 && hour <= 15) score += 10;
    if (hour < 9) score -= 10;
    if (hour > 16) score -= 15;
    return Math.max(0, score);
  };

  const createAppointment = (suggestion) => {
    const newApt = {
      id: Math.max(...appointments.map(a => a.id)) + 1,
      employeeId: newAppointment.selectedEmployees[0],
      title: newAppointment.title,
      date: suggestion.date,
      duration: newAppointment.duration,
      address: newAppointment.address,
      type: newAppointment.address ? 'external' : 'internal',
      allEmployees: newAppointment.selectedEmployees
    };
    
    setAppointments([...appointments, newApt]);
    setShowNewAppointment(false);
    setNewAppointment({
      title: '',
      address: '',
      duration: 60,
      selectedEmployees: [],
      preferredDate: new Date()
    });
    setSuggestions([]);
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
  };

  const getAppointmentsForDay = (employeeId, date) => {
    return appointments.filter(apt => 
      apt.employeeId === employeeId &&
      apt.date.toDateString() === date.toDateString()
    ).sort((a, b) => a.date - b.date);
  };

  const hours = Array.from({ length: 11 }, (_, i) => i + 7);

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)',
      color: '#e2e8f0',
      padding: '24px'
    }}>
      {/* Header */}
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '32px',
        paddingBottom: '24px',
        borderBottom: '1px solid rgba(255,255,255,0.1)',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h1 style={{
            fontSize: '28px',
            fontWeight: '700',
            margin: 0,
            background: 'linear-gradient(135deg, #60a5fa, #a78bfa)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            letterSpacing: '-0.5px'
          }}>
            Team Scheduler
          </h1>
          <p style={{ margin: '4px 0 0', color: '#94a3b8', fontSize: '14px' }}>
            Intelligente Terminplanung mit Routenoptimierung
          </p>
        </div>
        
        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <button
            onClick={() => setShowSettings(true)}
            style={{
              padding: '10px 16px',
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '10px',
              color: '#94a3b8',
              cursor: 'pointer',
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              transition: 'all 0.2s'
            }}
          >
            ⚙️ API-Einstellungen
          </button>
          
          <button
            onClick={() => setShowNewAppointment(true)}
            style={{
              padding: '10px 20px',
              background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
              border: 'none',
              borderRadius: '10px',
              color: 'white',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              boxShadow: '0 4px 15px rgba(59, 130, 246, 0.4)',
              transition: 'all 0.2s'
            }}
          >
            <span style={{ fontSize: '18px' }}>+</span> Neuer Termin
          </button>
        </div>
      </header>

      {/* Date Navigation */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        marginBottom: '24px',
        flexWrap: 'wrap'
      }}>
        <button
          onClick={() => {
            const newDate = new Date(selectedDate);
            newDate.setDate(newDate.getDate() - 1);
            setSelectedDate(newDate);
          }}
          style={{
            width: '40px',
            height: '40px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '10px',
            color: '#e2e8f0',
            cursor: 'pointer',
            fontSize: '18px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          ←
        </button>
        
        <div style={{
          padding: '10px 20px',
          background: 'rgba(255,255,255,0.05)',
          borderRadius: '10px',
          fontWeight: '600'
        }}>
          {selectedDate.toLocaleDateString('de-DE', { 
            weekday: 'long', 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}
        </div>
        
        <button
          onClick={() => {
            const newDate = new Date(selectedDate);
            newDate.setDate(newDate.getDate() + 1);
            setSelectedDate(newDate);
          }}
          style={{
            width: '40px',
            height: '40px',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '10px',
            color: '#e2e8f0',
            cursor: 'pointer',
            fontSize: '18px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          →
        </button>
        
        <button
          onClick={() => setSelectedDate(new Date())}
          style={{
            padding: '10px 16px',
            background: 'rgba(59, 130, 246, 0.2)',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            borderRadius: '10px',
            color: '#60a5fa',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500'
          }}
        >
          Heute
        </button>
      </div>

      {/* Calendar Grid */}
      <div style={{
        background: 'rgba(255,255,255,0.02)',
        borderRadius: '16px',
        border: '1px solid rgba(255,255,255,0.05)',
        overflow: 'auto'
      }}>
        {/* Employee Headers */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '80px repeat(4, minmax(200px, 1fr))',
          borderBottom: '1px solid rgba(255,255,255,0.1)',
          minWidth: '900px'
        }}>
          <div style={{ padding: '16px', background: 'rgba(0,0,0,0.2)' }}></div>
          {employees.map(emp => (
            <div key={emp.id} style={{
              padding: '16px',
              background: 'rgba(0,0,0,0.2)',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              borderLeft: '1px solid rgba(255,255,255,0.05)'
            }}>
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '12px',
                background: `linear-gradient(135deg, ${emp.color}, ${emp.color}88)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: '600',
                fontSize: '14px',
                boxShadow: `0 4px 12px ${emp.color}40`,
                flexShrink: 0
              }}>
                {emp.avatar}
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: '600', fontSize: '14px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{emp.name}</div>
                <div style={{ fontSize: '12px', color: '#94a3b8', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{emp.baseLocation.address}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Time Grid */}
        <div style={{ display: 'flex', minWidth: '900px' }}>
          {/* Time Labels */}
          <div style={{ width: '80px', flexShrink: 0 }}>
            {hours.map(hour => (
              <div key={hour} style={{
                height: '60px',
                padding: '8px 12px',
                fontSize: '12px',
                color: '#64748b',
                fontFamily: "'JetBrains Mono', monospace",
                borderBottom: '1px solid rgba(255,255,255,0.03)'
              }}>
                {`${hour.toString().padStart(2, '0')}:00`}
              </div>
            ))}
          </div>

          {/* Employee Columns */}
          {employees.map(emp => (
            <div key={emp.id} style={{
              flex: 1,
              minWidth: '200px',
              borderLeft: '1px solid rgba(255,255,255,0.05)',
              position: 'relative',
              minHeight: `${hours.length * 60}px`
            }}>
              {hours.map(hour => (
                <div key={hour} style={{
                  height: '60px',
                  borderBottom: '1px solid rgba(255,255,255,0.03)'
                }} />
              ))}
              
              {getAppointmentsForDay(emp.id, selectedDate).map(apt => {
                const startHour = apt.date.getHours();
                const startMinute = apt.date.getMinutes();
                const top = ((startHour - 7) * 60 + startMinute);
                const height = apt.duration;
                
                return (
                  <div
                    key={apt.id}
                    style={{
                      position: 'absolute',
                      top: `${top}px`,
                      left: '4px',
                      right: '4px',
                      height: `${height - 4}px`,
                      background: apt.type === 'external' 
                        ? `linear-gradient(135deg, ${emp.color}dd, ${emp.color}99)`
                        : apt.type === 'travel'
                        ? 'linear-gradient(135deg, #475569, #334155)'
                        : `linear-gradient(135deg, ${emp.color}66, ${emp.color}44)`,
                      borderRadius: '8px',
                      padding: '8px 10px',
                      fontSize: '12px',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      border: apt.type === 'external' 
                        ? `2px solid ${emp.color}`
                        : '1px solid rgba(255,255,255,0.1)',
                      boxShadow: apt.type === 'external' 
                        ? `0 4px 12px ${emp.color}30`
                        : 'none',
                      transition: 'all 0.2s'
                    }}
                  >
                    <div style={{ fontWeight: '600', marginBottom: '2px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {apt.title}
                    </div>
                    <div style={{ 
                      fontSize: '11px', 
                      opacity: 0.8,
                      fontFamily: "'JetBrains Mono', monospace"
                    }}>
                      {formatTime(apt.date)} - {formatTime(new Date(apt.date.getTime() + apt.duration * 60000))}
                    </div>
                    {apt.address && (
                      <div style={{ 
                        fontSize: '10px', 
                        marginTop: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis'
                      }}>
                        📍 {apt.address}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* New Appointment Modal */}
      {showNewAppointment && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px',
          animation: 'slideIn 0.3s ease'
        }}>
          <div style={{
            background: 'linear-gradient(145deg, #1e293b, #0f172a)',
            borderRadius: '20px',
            padding: '32px',
            width: '100%',
            maxWidth: '800px',
            maxHeight: '90vh',
            overflow: 'auto',
            border: '1px solid rgba(255,255,255,0.1)',
            boxShadow: '0 25px 50px rgba(0,0,0,0.5)'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '24px'
            }}>
              <h2 style={{ margin: 0, fontSize: '22px', fontWeight: '700' }}>
                ✨ Neuen Termin erstellen
              </h2>
              <button
                onClick={() => {
                  setShowNewAppointment(false);
                  setSuggestions([]);
                }}
                style={{
                  width: '36px',
                  height: '36px',
                  background: 'rgba(255,255,255,0.1)',
                  border: 'none',
                  borderRadius: '10px',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  fontSize: '18px'
                }}
              >
                ×
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '32px' }}>
              {/* Left: Form */}
              <div>
                <div style={{ marginBottom: '20px' }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '8px', 
                    fontSize: '13px',
                    fontWeight: '600',
                    color: '#94a3b8',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>
                    Titel
                  </label>
                  <input
                    type="text"
                    value={newAppointment.title}
                    onChange={e => setNewAppointment({...newAppointment, title: e.target.value})}
                    placeholder="z.B. Kundentermin Firma XY"
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      background: 'rgba(0,0,0,0.3)',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '10px',
                      color: '#e2e8f0',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>

                <div style={{ marginBottom: '20px' }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '8px', 
                    fontSize: '13px',
                    fontWeight: '600',
                    color: '#94a3b8',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>
                    📍 Adresse (für Außentermine)
                  </label>
                  <input
                    type="text"
                    value={newAppointment.address}
                    onChange={e => setNewAppointment({...newAppointment, address: e.target.value})}
                    placeholder="z.B. Bremen, Domshof 12"
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      background: 'rgba(0,0,0,0.3)',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '10px',
                      color: '#e2e8f0',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                  <p style={{ 
                    fontSize: '12px', 
                    color: '#64748b', 
                    marginTop: '6px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}>
                    💡 Leer lassen für interne Termine
                  </p>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                  <div>
                    <label style={{ 
                      display: 'block', 
                      marginBottom: '8px', 
                      fontSize: '13px',
                      fontWeight: '600',
                      color: '#94a3b8',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px'
                    }}>
                      Dauer
                    </label>
                    <select
                      value={newAppointment.duration}
                      onChange={e => setNewAppointment({...newAppointment, duration: parseInt(e.target.value)})}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        background: 'rgba(0,0,0,0.3)',
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '10px',
                        color: '#e2e8f0',
                        fontSize: '14px',
                        cursor: 'pointer'
                      }}
                    >
                      <option value={30}>30 Min.</option>
                      <option value={60}>1 Std.</option>
                      <option value={90}>1,5 Std.</option>
                      <option value={120}>2 Std.</option>
                      <option value={180}>3 Std.</option>
                      <option value={240}>4 Std.</option>
                    </select>
                  </div>
                  
                  <div>
                    <label style={{ 
                      display: 'block', 
                      marginBottom: '8px', 
                      fontSize: '13px',
                      fontWeight: '600',
                      color: '#94a3b8',
                      textTransform: 'uppercase',
                      letterSpacing: '0.5px'
                    }}>
                      Datum
                    </label>
                    <input
                      type="date"
                      value={newAppointment.preferredDate.toISOString().split('T')[0]}
                      onChange={e => setNewAppointment({
                        ...newAppointment, 
                        preferredDate: new Date(e.target.value)
                      })}
                      style={{
                        width: '100%',
                        padding: '14px 16px',
                        background: 'rgba(0,0,0,0.3)',
                        border: '1px solid rgba(255,255,255,0.1)',
                        borderRadius: '10px',
                        color: '#e2e8f0',
                        fontSize: '14px',
                        cursor: 'pointer'
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '12px', 
                    fontSize: '13px',
                    fontWeight: '600',
                    color: '#94a3b8',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px'
                  }}>
                    👥 Teilnehmer
                  </label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                    {employees.map(emp => (
                      <label
                        key={emp.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          padding: '12px 14px',
                          background: newAppointment.selectedEmployees.includes(emp.id)
                            ? `${emp.color}30`
                            : 'rgba(0,0,0,0.2)',
                          border: newAppointment.selectedEmployees.includes(emp.id)
                            ? `2px solid ${emp.color}`
                            : '2px solid rgba(255,255,255,0.1)',
                          borderRadius: '10px',
                          cursor: 'pointer',
                          transition: 'all 0.2s'
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={newAppointment.selectedEmployees.includes(emp.id)}
                          onChange={e => {
                            if (e.target.checked) {
                              setNewAppointment({
                                ...newAppointment,
                                selectedEmployees: [...newAppointment.selectedEmployees, emp.id]
                              });
                            } else {
                              setNewAppointment({
                                ...newAppointment,
                                selectedEmployees: newAppointment.selectedEmployees.filter(id => id !== emp.id)
                              });
                            }
                          }}
                          style={{ display: 'none' }}
                        />
                        <div style={{
                          width: '32px',
                          height: '32px',
                          borderRadius: '8px',
                          background: emp.color,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontWeight: '600',
                          fontSize: '12px',
                          flexShrink: 0
                        }}>
                          {emp.avatar}
                        </div>
                        <span style={{ fontSize: '14px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{emp.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right: Suggestions */}
              <div>
                <h3 style={{ 
                  margin: '0 0 16px', 
                  fontSize: '15px', 
                  fontWeight: '600',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}>
                  🎯 Terminvorschläge
                </h3>
                
                {newAppointment.selectedEmployees.length === 0 ? (
                  <div style={{
                    padding: '40px 20px',
                    background: 'rgba(0,0,0,0.2)',
                    borderRadius: '12px',
                    textAlign: 'center',
                    color: '#64748b'
                  }}>
                    <div style={{ fontSize: '40px', marginBottom: '12px' }}>👆</div>
                    <p>Wähle mindestens einen Teilnehmer</p>
                  </div>
                ) : suggestions.length === 0 ? (
                  <div style={{
                    padding: '40px 20px',
                    background: 'rgba(0,0,0,0.2)',
                    borderRadius: '12px',
                    textAlign: 'center',
                    color: '#64748b'
                  }}>
                    <div style={{ 
                      fontSize: '24px', 
                      marginBottom: '12px',
                      animation: 'pulse 1.5s ease infinite'
                    }}>
                      🔍
                    </div>
                    <p>Gib eine Adresse ein für Vorschläge</p>
                  </div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                    {suggestions.map((suggestion, idx) => (
                      <div
                        key={idx}
                        className="suggestion-card"
                        onClick={() => createAppointment(suggestion)}
                        style={{
                          padding: '16px',
                          background: idx === 0 
                            ? 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(139, 92, 246, 0.2))'
                            : 'rgba(0,0,0,0.2)',
                          border: idx === 0 
                            ? '2px solid #3b82f6' 
                            : '1px solid rgba(255,255,255,0.1)',
                          borderRadius: '12px',
                          cursor: 'pointer',
                          position: 'relative'
                        }}
                      >
                        {idx === 0 && (
                          <div style={{
                            position: 'absolute',
                            top: '-8px',
                            right: '12px',
                            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                            padding: '4px 10px',
                            borderRadius: '6px',
                            fontSize: '10px',
                            fontWeight: '600',
                            textTransform: 'uppercase',
                            letterSpacing: '0.5px'
                          }}>
                            ⭐ Empfohlen
                          </div>
                        )}
                        
                        <div style={{ 
                          display: 'flex', 
                          justifyContent: 'space-between',
                          alignItems: 'flex-start',
                          marginBottom: '8px'
                        }}>
                          <div>
                            <div style={{ 
                              fontWeight: '600', 
                              fontSize: '15px',
                              marginBottom: '2px'
                            }}>
                              {formatDate(suggestion.date)}
                            </div>
                            <div style={{ 
                              fontSize: '20px', 
                              fontWeight: '700',
                              fontFamily: "'JetBrains Mono', monospace"
                            }}>
                              {formatTime(suggestion.date)}
                            </div>
                          </div>
                          
                          <div style={{ textAlign: 'right' }}>
                            {suggestion.travelTime > 0 && (
                              <div style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '4px',
                                padding: '4px 10px',
                                background: suggestion.travelTime <= 45 
                                  ? 'rgba(16, 185, 129, 0.2)' 
                                  : 'rgba(245, 158, 11, 0.2)',
                                borderRadius: '6px',
                                fontSize: '12px',
                                color: suggestion.travelTime <= 45 ? '#10b981' : '#f59e0b'
                              }}>
                                🚗 ~{suggestion.travelTime} Min.
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div style={{
                          display: 'flex',
                          gap: '6px',
                          marginTop: '10px',
                          flexWrap: 'wrap'
                        }}>
                          {suggestion.employees.map(emp => (
                            <div
                              key={emp.id}
                              style={{
                                width: '28px',
                                height: '28px',
                                borderRadius: '6px',
                                background: emp.color,
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '10px',
                                fontWeight: '600'
                              }}
                              title={emp.name}
                            >
                              {emp.avatar}
                            </div>
                          ))}
                          <div style={{
                            padding: '6px 10px',
                            background: 'rgba(255,255,255,0.1)',
                            borderRadius: '6px',
                            fontSize: '11px',
                            color: '#94a3b8'
                          }}>
                            Alle verfügbar ✓
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {suggestions.length > 0 && (
                  <p style={{ 
                    fontSize: '11px', 
                    color: '#64748b', 
                    marginTop: '16px',
                    textAlign: 'center'
                  }}>
                    💡 Klicke auf einen Vorschlag
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0,0,0,0.7)',
          backdropFilter: 'blur(8px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          padding: '20px'
        }}>
          <div style={{
            background: 'linear-gradient(145deg, #1e293b, #0f172a)',
            borderRadius: '20px',
            padding: '32px',
            width: '100%',
            maxWidth: '500px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '24px'
            }}>
              <h2 style={{ margin: 0, fontSize: '20px', fontWeight: '700' }}>
                ⚙️ API-Einstellungen
              </h2>
              <button
                onClick={() => setShowSettings(false)}
                style={{
                  width: '36px',
                  height: '36px',
                  background: 'rgba(255,255,255,0.1)',
                  border: 'none',
                  borderRadius: '10px',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  fontSize: '18px'
                }}
              >
                ×
              </button>
            </div>

            <div style={{
              padding: '16px',
              background: 'rgba(245, 158, 11, 0.1)',
              border: '1px solid rgba(245, 158, 11, 0.3)',
              borderRadius: '10px',
              marginBottom: '24px'
            }}>
              <p style={{ margin: 0, fontSize: '13px', color: '#fbbf24' }}>
                ⚠️ <strong>Demo-Modus aktiv</strong><br/>
                Die App läuft mit simulierten Daten.
              </p>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ 
                display: 'block', 
                marginBottom: '8px', 
                fontSize: '13px',
                fontWeight: '600',
                color: '#94a3b8'
              }}>
                Google Calendar API Key
              </label>
              <input
                type="password"
                value={apiKeys.googleCalendar}
                onChange={e => setApiKeys({...apiKeys, googleCalendar: e.target.value})}
                placeholder="AIza..."
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: 'rgba(0,0,0,0.3)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '10px',
                  color: '#e2e8f0',
                  fontSize: '14px'
                }}
              />
            </div>

            <div style={{ marginBottom: '24px' }}>
              <label style={{ 
                display: 'block', 
                marginBottom: '8px', 
                fontSize: '13px',
                fontWeight: '600',
                color: '#94a3b8'
              }}>
                Google Maps API Key
              </label>
              <input
                type="password"
                value={apiKeys.googleMaps}
                onChange={e => setApiKeys({...apiKeys, googleMaps: e.target.value})}
                placeholder="AIza..."
                style={{
                  width: '100%',
                  padding: '14px 16px',
                  background: 'rgba(0,0,0,0.3)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '10px',
                  color: '#e2e8f0',
                  fontSize: '14px'
                }}
              />
            </div>

            <button
              onClick={() => {
                alert('Gespeichert! (Demo-Modus)');
                setShowSettings(false);
              }}
              style={{
                width: '100%',
                padding: '14px',
                background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                border: 'none',
                borderRadius: '10px',
                color: 'white',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              Speichern
            </button>
          </div>
        </div>
      )}

      {/* Footer */}
      <div style={{
        marginTop: '24px',
        padding: '16px',
        background: 'rgba(255,255,255,0.02)',
        borderRadius: '12px',
        border: '1px solid rgba(255,255,255,0.05)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        fontSize: '12px',
        color: '#64748b',
        flexWrap: 'wrap',
        gap: '12px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
          <span>🟢 Demo-Modus</span>
          <span>•</span>
          <span>4 Mitarbeiter</span>
          <span>•</span>
          <span>{appointments.length} Termine</span>
        </div>
        <div>
          Team Scheduler v1.0
        </div>
      </div>
    </div>
  );
}
